# Music_store_data_analysis
This is a SQL project to analyze Music Store Data. In this project, I used MYSQL and tried to solve some basic to advanced queries to analyze.
